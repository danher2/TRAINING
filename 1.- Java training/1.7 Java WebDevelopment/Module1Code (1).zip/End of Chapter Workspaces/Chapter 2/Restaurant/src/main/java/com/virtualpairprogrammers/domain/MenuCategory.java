package com.virtualpairprogrammers.domain;

public enum MenuCategory {
	STARTER, MAIN_COURSE, DESERT, DRINK
}
